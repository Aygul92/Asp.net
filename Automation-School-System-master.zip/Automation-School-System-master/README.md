# Automation-School-System
In this project,I crated a automation school system project by using Asp.Net . My project consists of 2 basic modules. The first is the Student panel, the second is the Academic panel. There is a separate entrance page for each module. 

Students login:


![ST](https://user-images.githubusercontent.com/26111615/105859294-a334d000-5fec-11eb-88ba-0227ba26b3cb.png)



Teatchers login :

![st_login](https://user-images.githubusercontent.com/26111615/105859553-f1e26a00-5fec-11eb-833b-82a9d17f748f.png)
